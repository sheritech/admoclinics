<?php
// Setup Laboratory Tables
include('hms/include/config.php');

$sql = file_get_contents('laboratory_tables.sql');

// Split by semicolon but handle CREATE TABLE blocks
$statements = [];
$current = '';
$inCreate = false;

foreach(explode("\n", $sql) as $line){
    $line = trim($line);
    if(empty($line) || strpos($line, '--') === 0) continue;

    $current .= $line . "\n";

    if(strpos(strtoupper($line), 'CREATE TABLE') === 0){
        $inCreate = true;
    }

    if(strpos($line, ';') !== false && $inCreate){
        $statements[] = trim($current);
        $current = '';
        $inCreate = false;
    }
}

// Handle INSERT statements
foreach(explode(';', $sql) as $part){
    $part = trim($part);
    if(strpos(strtoupper($part), 'INSERT') === 0){
        $statements[] = $part . ';';
    }
}

$success = 0;
$errors = [];

foreach($statements as $statement){
    $statement = trim($statement);
    if(!empty($statement)){
        if(mysqli_query($con, $statement)){
            $success++;
        } else {
            $errors[] = mysqli_error($con) . " in: " . substr($statement, 0, 100) . "...";
        }
    }
}

echo "<h2>Laboratory Setup Complete</h2>";
echo "<p>Statements executed: $success</p>";
if(!empty($errors)){
    echo "<p>Errors:</p><ul>";
    foreach($errors as $error){
        echo "<li>$error</li>";
    }
    echo "</ul>";
} else {
    echo "<p>No errors occurred.</p>";
}
echo "<p><a href='hms/laboratory/index.php'>Go to Laboratory Login</a></p>";
?>