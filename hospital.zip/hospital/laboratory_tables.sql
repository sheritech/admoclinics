-- Laboratory Tables for HMS

-- Lab Test Types Table
CREATE TABLE IF NOT EXISTS lab_test_types (
    type_id INT AUTO_INCREMENT PRIMARY KEY,
    test_name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) DEFAULT 0.00,
    sample_type VARCHAR(100),
    normal_range VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Lab Staff Table
CREATE TABLE IF NOT EXISTS tbllabstaff (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- External Clients Table
CREATE TABLE IF NOT EXISTS tblclient_external (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ClientName VARCHAR(100) NOT NULL,
    contact VARCHAR(50) NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Lab Tests Table
CREATE TABLE IF NOT EXISTS lab_tests (
    test_id INT AUTO_INCREMENT PRIMARY KEY,
    type_id INT NOT NULL,
    test_name VARCHAR(255) NOT NULL,
    test_date DATE NOT NULL,
    patient_id INT NULL,
    client_id INT NULL,
    doctor_id INT NULL,
    reference_range TEXT NULL,
    status VARCHAR(50) DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (type_id) REFERENCES lab_test_types(type_id) ON DELETE CASCADE,
    FOREIGN KEY (patient_id) REFERENCES tblpatient(ID) ON DELETE SET NULL,
    FOREIGN KEY (client_id) REFERENCES tblclient_external(id) ON DELETE SET NULL,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE SET NULL
);

-- Lab Results Table
CREATE TABLE IF NOT EXISTS lab_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    test_id INT NOT NULL,
    result_value VARCHAR(255) NOT NULL,
    result_notes TEXT,
    result_file VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (test_id) REFERENCES lab_tests(test_id) ON DELETE CASCADE
);

-- Lab Staff Logs Table
CREATE TABLE IF NOT EXISTS labstafflog (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    username VARCHAR(50) NOT NULL,
    userip VARCHAR(50) NOT NULL,
    status INT DEFAULT 1,
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    logout_time TIMESTAMP NULL,
    FOREIGN KEY (uid) REFERENCES tbllabstaff(ID) ON DELETE CASCADE
);

-- Insert default lab staff (username: lab, password: lab123)
INSERT IGNORE INTO tbllabstaff (Username, Password) VALUES ('lab', MD5('lab123'));