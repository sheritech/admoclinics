<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>

						<!-- start: MAIN NAVIGATION MENU -->
						<div class="navbar-title">
							<span>Main Navigation</span>
						</div>
						<ul class="main-navigation-menu">
							<?php if(isset($_SESSION['pharmaid'])) { ?>
							<!-- Pharmacy Menu -->
							<li>
								<a href="dashboard.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="medicines-list.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Medicines List </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="medicines-add.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-plus"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Add Medicine </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="sale-new.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-shopping-cart"></i>
										</div>
										<div class="item-inner">
											<span class="title"> New Sale </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="stock-log.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-bar-chart"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Stock Log </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="invoice.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-receipt"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Invoice </span>
										</div>
									</div>
								</a>
							</li>
							<?php } elseif(isset($_SESSION['labid'])) { ?>
							<!-- Laboratory Menu -->
							<li>
								<a href="dashboard.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="tests-list.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Tests List </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="results-upload.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-upload"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Upload Results </span>
										</div>
									</div>
								</a>
							</li>
							<?php } else { ?>
							<!-- Default Patient Menu -->
							<li>
								<a href="dashboard.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="book-appointment.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-pencil-alt"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Book Appointment </span>
										</div>
									</div>
								</a>
							</li>

							<li>
								<a href="appointment-history.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Appointment History </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="manage-medhistory.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Medical History </span>
										</div>
									</div>
								</a>
							</li>
							<?php } ?>
						</ul>
						<!-- end: CORE FEATURES -->

					</nav>
					</div>
			</div>