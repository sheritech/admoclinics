<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['pharmaid'])==0){ header('location:index.php'); }

$sale_id=intval($_GET['sale_id']);
$qSale=mysqli_query($con,"SELECT s.*,p.PatientName FROM pharmacy_sales s 
  LEFT JOIN tblpatient p ON s.patient_id=p.ID 
  WHERE s.sale_id=$sale_id");
$sale=mysqli_fetch_array($qSale);

$qItems=mysqli_query($con,"SELECT si.*,m.name FROM pharmacy_sale_items si 
  JOIN pharmacy_medicines m ON si.medicine_id=m.medicine_id 
  WHERE si.sale_id=$sale_id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pharmacy | Invoice #<?php echo $sale_id; ?></title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
  <link href="../assets/css/styles.css" rel="stylesheet">
  <link href="../assets/css/plugins.css" rel="stylesheet">
  <link href="../assets/css/themes/theme-1.css" rel="stylesheet" id="skin_color" />
  <style>
    @media print {
      .app-sidebar, .app-header, .app-footer, .main-content, .wrap-content, .container-fluid, .panel, .breadcrumb, #page-title {
        display: none !important;
      }
      .thermal-invoice {
        display: block !important;
        width: 58mm;
        font-size: 10px;
        font-family: monospace;
        margin: 0;
        padding: 5px;
        border: none;
        background: white;
      }
      .thermal-invoice h2 {
        font-size: 12px;
        text-align: center;
        margin: 5px 0;
      }
      .thermal-invoice p {
        margin: 2px 0;
      }
      .thermal-invoice table {
        width: 100%;
        border-collapse: collapse;
        font-size: 9px;
      }
      .thermal-invoice table th, .thermal-invoice table td {
        padding: 2px;
        text-align: left;
      }
      .thermal-invoice .text-center {
        text-align: center;
      }
      .thermal-invoice .text-right {
        text-align: right;
      }
    }
    .thermal-invoice {
      display: none;
    }
  </style>
</head>
<body>
<div id="app">
  <?php include('include/sidebar.php'); ?>
  <div class="app-content">
    <?php include('include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container" id="container">
        
        <section id="page-title">
          <div class="row">
            <div class="col-sm-8">
              <h1 class="mainTitle">Pharmacy | Invoice</h1>
            </div>
            <ol class="breadcrumb">
              <li><span>Pharmacy</span></li>
              <li class="active"><span>Invoice</span></li>
            </ol>
          </div>
        </section>

        <!-- Invoice Box -->
        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <div class="col-md-12">
              <div class="invoice-box panel panel-default" style="padding:20px;">
                <h2 class="text-center">Hospital Pharmacy Invoice</h2>
                <p>
                  <b>Invoice ID:</b> #<?php echo $sale_id; ?><br>
                  <b>Date:</b> <?php echo $sale['sale_date']; ?><br>
                  <b>Patient:</b> <?php echo $sale['PatientName'] ?? 'Walk-in'; ?>
                </p>

                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>Medicine</th>
                      <th>Qty</th>
                      <th>Price</th>
                      <th>Subtotal</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $total=0;
                  mysqli_data_seek($qItems, 0); // Reset pointer
                  while($row=mysqli_fetch_array($qItems)){
                    $total+=$row['subtotal']; ?>
                    <tr>
                      <td><?php echo $row['name']; ?></td>
                      <td><?php echo $row['quantity']; ?></td>
                      <td><?php echo number_format($row['price'],2); ?></td>
                      <td><?php echo number_format($row['subtotal'],2); ?></td>
                    </tr>
                  <?php } ?>
                    <tr>
                      <td colspan="3" class="text-right"><b>Total</b></td>
                      <td><b><?php echo number_format($total,2); ?></b></td>
                    </tr>
                  </tbody>
                </table>

                <div class="text-center">
                  <button class="btn btn-primary" onclick="window.print()">
                    <i class="fa fa-print"></i> Print Invoice
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End Invoice Box -->

      </div>
    </div>
  </div>
  <?php include('include/footer.php'); ?>
</div>

<!-- Thermal Invoice for Printing -->
<div class="thermal-invoice">
 <h2>Hospital Pharmacy</h2>
 <p>Invoice #<?php echo $sale_id; ?></p>
 <p>Date: <?php echo date('d/m/Y H:i', strtotime($sale['sale_date'])); ?></p>
 <p>Patient: <?php echo $sale['PatientName'] ?? 'Walk-in'; ?></p>
 <hr>
 <table>
   <thead>
     <tr>
       <th>Item</th>
       <th>Qty</th>
       <th>Price</th>
       <th>Total</th>
     </tr>
   </thead>
   <tbody>
   <?php $total=0;
   mysqli_data_seek($qItems, 0); // Reset pointer
   while($row=mysqli_fetch_array($qItems)){
     $total+=$row['subtotal']; ?>
     <tr>
       <td><?php echo substr($row['name'], 0, 15); ?></td>
       <td><?php echo $row['quantity']; ?></td>
       <td><?php echo number_format($row['price'],2); ?></td>
       <td><?php echo number_format($row['subtotal'],2); ?></td>
     </tr>
   <?php } ?>
     <tr>
       <td colspan="3" class="text-right"><b>Total:</b></td>
       <td><b><?php echo number_format($total,2); ?></b></td>
     </tr>
   </tbody>
 </table>
 <hr>
 <p class="text-center">Thank you for your visit!</p>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../vendor/modernizr/modernizr.js"></script>
<script src="../vendor/jquery-cookie/jquery.cookie.js"></script>
<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="../vendor/switchery/switchery.min.js"></script>
<script src="../assets/js/main.js"></script>
<script>
  jQuery(document).ready(function() {
    Main.init();
  });
</script>
</body>
</html>
