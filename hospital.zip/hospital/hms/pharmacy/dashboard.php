<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['pharmaid'])==0){
  header('location:index.php');
} else {
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pharmacy | Dashboard</title>
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
    <link href="../vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="../vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="../vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="../assets/css/styles.css" rel="stylesheet">
    <link href="../assets/css/plugins.css" rel="stylesheet">
    <link href="../assets/css/themes/theme-1.css" rel="stylesheet" id="skin_color" />
  </head>
  <body>
    <div id="app">
      <?php include('include/sidebar.php'); ?>
      <div class="app-content">
        <?php include('include/header.php'); ?>
        <div class="main-content">
          <div class="wrap-content container" id="container">
            <!-- Page Title -->
            <section id="page-title">
              <div class="row">
                <div class="col-sm-8">
                  <h1 class="mainTitle">Pharmacy | Dashboard</h1>
                </div>
                <ol class="breadcrumb">
                  <li><span>Pharmacy</span></li>
                  <li class="active"><span>Dashboard</span></li>
                </ol>
              </div>
            </section>

            <!-- Content -->
            <div class="container-fluid container-fullw bg-white">
              <div class="row">
                <div class="col-sm-6">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x">
                        <i class="fa fa-square fa-stack-2x text-primary"></i>
                        <i class="fa fa-medkit fa-stack-1x fa-inverse"></i>
                      </span>
                      <h2 class="StepTitle">Manage Medicines</h2>
                      <p class="links cl-effect-1">
                        <a href="medicines-list.php">Go to Medicines</a>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x">
                        <i class="fa fa-square fa-stack-2x text-primary"></i>
                        <i class="fa fa-list fa-stack-1x fa-inverse"></i>
                      </span>
                      <h2 class="StepTitle">Stock Movements</h2>
                      <p class="links cl-effect-1">
                        <a href="stock-log.php">View Logs</a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <?php
                $low_stock_query = mysqli_query($con, "SELECT COUNT(*) as count FROM pharmacy_medicines WHERE quantity <= 10");
                $low_stock = mysqli_fetch_array($low_stock_query)['count'];

                $expiring_query = mysqli_query($con, "SELECT COUNT(*) as count FROM pharmacy_medicines WHERE expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)");
                $expiring = mysqli_fetch_array($expiring_query)['count'];
                ?>
                <div class="col-sm-6">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x">
                        <i class="fa fa-square fa-stack-2x text-warning"></i>
                        <i class="fa fa-exclamation-triangle fa-stack-1x fa-inverse"></i>
                      </span>
                      <h2 class="StepTitle">Low Stock Alert</h2>
                      <p class="text-danger"><strong><?php echo $low_stock; ?> medicines</strong> have low stock (≤10)</p>
                      <p class="links cl-effect-1">
                        <a href="medicines-list.php">View Medicines</a>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x">
                        <i class="fa fa-square fa-stack-2x text-danger"></i>
                        <i class="fa fa-calendar-times-o fa-stack-1x fa-inverse"></i>
                      </span>
                      <h2 class="StepTitle">Expiry Alert</h2>
                      <p class="text-danger"><strong><?php echo $expiring; ?> medicines</strong> expiring within 30 days</p>
                      <p class="links cl-effect-1">
                        <a href="medicines-list.php">View Medicines</a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- End Content -->

          </div>
        </div>
      </div>
      <?php include('include/footer.php'); ?>
    </div>

    <!-- Scripts -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="../vendor/modernizr/modernizr.js"></script>
    <script src="../vendor/jquery-cookie/jquery.cookie.js"></script>
    <script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="../vendor/switchery/switchery.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
      jQuery(document).ready(function() {
        Main.init();
      });
    </script>
  </body>
</html>
<?php } ?>
