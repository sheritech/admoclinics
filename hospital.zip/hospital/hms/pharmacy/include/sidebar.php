<div class="sidebar app-aside" id="sidebar">
    <div class="sidebar-container perfect-scrollbar">
        <nav>
            <div class="navbar-title">
                <span>Main Navigation</span>
            </div>
            <ul class="main-navigation-menu">

                <li>
                    <a href="dashboard.php">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-home"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Dashboard </span>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="javascript:void(0)">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-package"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Medicines </span><i class="icon-arrow"></i>
                            </div>
                        </div>
                    </a>
                    <ul class="sub-menu">
                        <li>
                            <a href="medicines-add.php"> Add Medicine </a>
                        </li>
                        <li>
                            <a href="medicines-list.php"> Manage Medicines </a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="sale-new.php">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-shopping-cart"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> New Sale (Invoice) </span>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="stock-log.php">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-bar-chart"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Stock Movements </span>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="bulk-import.php">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-upload"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Bulk Import </span>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="logout.php">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-power-off"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Logout </span>
                            </div>
                        </div>
                    </a>
                </li>

            </ul>
        </nav>
    </div>
</div>
