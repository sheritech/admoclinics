<?php
session_start();
include('../include/config.php');

if(isset($_SESSION['pharmaid'])){
    $log_id = $_SESSION['pharma_log_id'] ?? 0;
    if($log_id>0){
        mysqli_query($con,"UPDATE pharmacistlog SET logoutTime=NOW() WHERE id=$log_id");
    }
}
session_unset();
session_destroy();
header('location:index.php');
?>
