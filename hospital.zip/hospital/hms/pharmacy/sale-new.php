<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['pharmaid'])==0){ header('location:index.php'); }

if(isset($_POST['submit'])){
    $patient_id = !empty($_POST['patient_id']) ? $_POST['patient_id'] : NULL;
    $pharmacist_id = $_SESSION['pharmaid'];
    $medicines = isset($_POST['medicine']) ? $_POST['medicine'] : [];
    $quantities = isset($_POST['quantity']) ? $_POST['quantity'] : [];

    if(empty($medicines)){
        echo "<script>alert('Please select at least one medicine');</script>";
        exit;
    }

    $total = 0;
    $items = [];

    foreach($medicines as $key => $med_id){
        $qty = intval($quantities[$key]);
        if($qty > 0){
            $qMed = mysqli_query($con,"SELECT * FROM pharmacy_medicines WHERE medicine_id=$med_id");
            $med = mysqli_fetch_array($qMed);

            $price = $med['mrp'];
            $subtotal = $price * $qty;
            $total += $subtotal;

            $items[] = [
                'medicine_id' => $med_id,
                'qty' => $qty,
                'price' => $price,
                'subtotal' => $subtotal
            ];

            mysqli_query($con,"UPDATE pharmacy_medicines SET quantity=quantity-$qty WHERE medicine_id=$med_id");
            mysqli_query($con,"INSERT INTO pharmacy_stock_log(medicine_id,change_qty,action,remarks) 
                               VALUES($med_id,-$qty,'SALE','Sold via invoice')");
        }
    }

    mysqli_query($con,"INSERT INTO pharmacy_sales(patient_id,pharmacist_id,total_amount)
                       VALUES(".($patient_id ? "'$patient_id'" : "NULL").",'$pharmacist_id','$total')");
    $sale_id = mysqli_insert_id($con);

    foreach($items as $i){
        mysqli_query($con,"INSERT INTO pharmacy_sale_items(sale_id,medicine_id,quantity,price,subtotal) 
                           VALUES($sale_id,'".$i['medicine_id']."','".$i['qty']."','".$i['price']."','".$i['subtotal']."')");
    }

    header("location:invoice.php?sale_id=".$sale_id);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pharmacy | New Sale</title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../assets/css/styles.css" rel="stylesheet">
</head>
<body>
<div id="app">
  <?php include('include/sidebar.php'); ?>
  <div class="app-content">
    <?php include('include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container" id="container">

        <section id="page-title">
          <div class="row">
            <div class="col-sm-8">
              <h1 class="mainTitle">Pharmacy | New Sale</h1>
            </div>
            <ol class="breadcrumb">
              <li><span>Pharmacy</span></li>
              <li class="active"><span>New Sale</span></li>
            </ol>
          </div>
        </section>

        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <div class="col-md-12">
              <div class="panel panel-white">
                <div class="panel-heading">
                  <h5 class="panel-title">Create New Sale</h5>
                </div>
                <div class="panel-body">
                  <form method="post">
                    <div class="form-group">
                      <label for="patient">Patient</label>
                      <select name="patient_id" class="form-control">
                        <option value="">Walk-in</option>
                        <?php
                        $qP = mysqli_query($con,"SELECT ID,PatientName FROM tblpatient ORDER BY PatientName");
                        while($p = mysqli_fetch_array($qP)){
                            echo "<option value='".$p['ID']."'>".$p['PatientName']."</option>";
                        }
                        ?>
                      </select>
                    </div>

                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Select</th>
                          <th>Medicine</th>
                          <th>Available</th>
                          <th>Price</th>
                          <th>Qty</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $qM = mysqli_query($con,"SELECT * FROM pharmacy_medicines ORDER BY name");
                        while($m = mysqli_fetch_array($qM)){ ?>
                          <tr>
                            <td><input type="checkbox" name="medicine[]" value="<?php echo $m['medicine_id']; ?>"></td>
                            <td><?php echo $m['name']; ?></td>
                            <td><?php echo $m['quantity']; ?></td>
                            <td><?php echo number_format($m['mrp'],2); ?></td>
                            <td><input type="number" name="quantity[]" class="form-control" value="0" min="0"></td>
                          </tr>
                        <?php } ?>
                      </tbody>
                    </table>

                    <button type="submit" name="submit" class="btn btn-success">
                      <i class="fa fa-file-text"></i> Generate Invoice
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
  <?php include('include/footer.php'); ?>
</div>
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/main.js"></script>
<script> jQuery(document).ready(function(){ Main.init(); }); </script>
</body>
</html>
