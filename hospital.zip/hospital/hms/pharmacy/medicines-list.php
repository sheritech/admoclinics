<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['pharmaid'])==0){ header('location:index.php'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pharmacy | Medicines List</title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
  <link href="../assets/css/styles.css" rel="stylesheet">
  <link href="../assets/css/plugins.css" rel="stylesheet">
  <link href="../assets/css/themes/theme-1.css" rel="stylesheet" id="skin_color" />
</head>
<body>
<div id="app">
  <?php include('include/sidebar.php'); ?>
  <div class="app-content">
    <?php include('include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container" id="container">

        <section id="page-title">
          <div class="row">
            <div class="col-sm-8">
              <h1 class="mainTitle">Pharmacy | Medicines List</h1>
            </div>
            <ol class="breadcrumb">
              <li><span>Pharmacy</span></li>
              <li class="active"><span>Medicines</span></li>
            </ol>
          </div>
        </section>

        <!-- Medicines Table -->
        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <div class="col-md-12">
              <div class="panel panel-white">
                <div class="panel-heading">
                  <h5 class="panel-title">Manage Medicines</h5>
                  <div class="text-right">
                    <a href="medicines-add.php" class="btn btn-primary btn-sm">
                      <i class="fa fa-plus"></i> Add Medicine
                    </a>
                  </div>
                </div>
                <div class="panel-body">
                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Barcode</th>
                        <th>Quantity</th>
                        <th>Expiry</th>
                        <th>Status</th>
                        <th>Price (MRP)</th>
                        <th>Cost</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                    $ret=mysqli_query($con,"SELECT * FROM pharmacy_medicines ORDER BY name");
                    $cnt=1;
                    while($row=mysqli_fetch_array($ret)){
                      $status = '';
                      $row_class = '';
                      $qty = $row['quantity'];
                      $expiry = $row['expiry_date'];
                      $today = date('Y-m-d');
                      $expiry_soon = date('Y-m-d', strtotime('+30 days'));

                      if ($qty <= 10) {
                        $status .= 'Low Stock ';
                        $row_class = 'warning';
                      }
                      if ($expiry < $today) {
                        $status .= 'Expired ';
                        $row_class = 'danger';
                      } elseif ($expiry <= $expiry_soon) {
                        $status .= 'Expiring Soon ';
                        if ($row_class != 'danger') $row_class = 'warning';
                      }
                      if (empty($status)) {
                        $status = 'OK';
                        $row_class = 'success';
                      }
                    ?>
                      <tr class="<?php echo $row_class; ?>">
                        <td><?php echo $cnt; ?></td>
                        <td><?php echo htmlentities($row['name']); ?></td>
                        <td><?php echo htmlentities($row['barcode']); ?></td>
                        <td><?php echo htmlentities($row['quantity']); ?></td>
                        <td><?php echo htmlentities($row['expiry_date']); ?></td>
                        <td><?php echo $status; ?></td>
                        <td><?php echo number_format($row['mrp'],2); ?></td>
                        <td><?php echo number_format($row['unit_price'],2); ?></td>
                        <td>
                          <a href="medicines-edit.php?id=<?php echo $row['medicine_id'];?>" class="btn btn-sm btn-info"><i class="fa fa-pencil"></i></a>
                          <a href="medicines-delete.php?id=<?php echo $row['medicine_id'];?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this medicine?');"><i class="fa fa-trash"></i></a>
                        </td>
                      </tr>
                    <?php $cnt=$cnt+1; } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End Medicines Table -->

      </div>
    </div>
  </div>
  <?php include('include/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../vendor/modernizr/modernizr.js"></script>
<script src="../vendor/jquery-cookie/jquery.cookie.js"></script>
<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="../vendor/switchery/switchery.min.js"></script>
<script src="../assets/js/main.js"></script>
<script>
  jQuery(document).ready(function() {
    Main.init();
  });
</script>
</body>
</html>
