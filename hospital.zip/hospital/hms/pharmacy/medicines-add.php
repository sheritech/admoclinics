<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['pharmaid'])==0){ header('location:index.php'); }

if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $barcode=$_POST['barcode'];
  $qty=$_POST['quantity'];
  $expiry=$_POST['expiry_date'];
  $mrp=$_POST['mrp'];
  $unit_price=$_POST['unit_price'];

  $sql="INSERT INTO pharmacy_medicines (name,barcode,quantity,expiry_date,mrp,unit_price) 
        VALUES ('$name','$barcode','$qty','$expiry','$mrp','$unit_price')";
  mysqli_query($con,$sql);
  echo "<script>alert('Medicine Added');</script>";
  echo "<script>window.location.href='medicines-list.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pharmacy | Add Medicine</title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
  <link href="../assets/css/styles.css" rel="stylesheet">
  <link href="../assets/css/plugins.css" rel="stylesheet">
  <link href="../assets/css/themes/theme-1.css" rel="stylesheet" id="skin_color" />
</head>
<body>
<div id="app">
  <?php include('include/sidebar.php'); ?>
  <div class="app-content">
    <?php include('include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container" id="container">

        <section id="page-title">
          <div class="row">
            <div class="col-sm-8">
              <h1 class="mainTitle">Pharmacy | Add Medicine</h1>
            </div>
            <ol class="breadcrumb">
              <li><span>Pharmacy</span></li>
              <li class="active"><span>Add Medicine</span></li>
            </ol>
          </div>
        </section>

        <!-- Add Medicine Form -->
        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="panel panel-white">
                <div class="panel-heading">
                  <h5 class="panel-title">Add New Medicine</h5>
                </div>
                <div class="panel-body">
                  <form role="form" method="post">
                    <div class="form-group">
                      <label for="name">Medicine Name</label>
                      <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                      <label for="barcode">Barcode</label>
                      <input type="text" name="barcode" class="form-control" required>
                    </div>
                    <div class="form-group">
                      <label for="quantity">Quantity</label>
                      <input type="number" name="quantity" class="form-control" required>
                    </div>
                    <div class="form-group">
                      <label for="expiry_date">Expiry Date</label>
                      <input type="date" name="expiry_date" class="form-control" required>
                    </div>
                    <div class="form-group">
                      <label for="mrp">Price (MRP)</label>
                      <input type="number" step="0.01" name="mrp" class="form-control" required>
                    </div>
                    <div class="form-group">
                      <label for="unit_price">Cost (Unit Price)</label>
                      <input type="number" step="0.01" name="unit_price" class="form-control">
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary">
                      <i class="fa fa-plus"></i> Add Medicine
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End Add Medicine Form -->

      </div>
    </div>
  </div>
  <?php include('include/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../vendor/modernizr/modernizr.js"></script>
<script src="../vendor/jquery-cookie/jquery.cookie.js"></script>
<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="../vendor/switchery/switchery.min.js"></script>
<script src="../assets/js/main.js"></script>
<script>
  jQuery(document).ready(function() {
    Main.init();
  });
</script>
</body>
</html>
