<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['pharmaid'])==0){ header('location:index.php'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pharmacy | Stock Log</title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../assets/css/styles.css" rel="stylesheet">
</head>
<body>
<div id="app">
  <?php include('include/sidebar.php'); ?>
  <div class="app-content">
    <?php include('include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container" id="container">

        <section id="page-title">
          <div class="row">
            <div class="col-sm-8">
              <h1 class="mainTitle">Pharmacy | Stock Movements</h1>
            </div>
            <ol class="breadcrumb">
              <li><span>Pharmacy</span></li>
              <li class="active"><span>Stock Log</span></li>
            </ol>
          </div>
        </section>

        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <div class="col-md-12">
              <div class="panel panel-white">
                <div class="panel-heading">
                  <h5 class="panel-title">Stock Movement History</h5>
                </div>
                <div class="panel-body">
                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Medicine</th>
                        <th>Change</th>
                        <th>Action</th>
                        <th>Remarks</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $ret=mysqli_query($con,"SELECT l.*,m.name FROM pharmacy_stock_log l JOIN pharmacy_medicines m ON l.medicine_id=m.medicine_id ORDER BY l.created_at DESC");
                      while($row=mysqli_fetch_array($ret)){ ?>
                      <tr>
                        <td><?php echo $row['log_id']; ?></td>
                        <td><?php echo htmlentities($row['name']); ?></td>
                        <td><?php echo $row['change_qty']; ?></td>
                        <td><?php echo $row['action']; ?></td>
                        <td><?php echo $row['remarks']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
  <?php include('include/footer.php'); ?>
</div>
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/main.js"></script>
<script> jQuery(document).ready(function(){ Main.init(); }); </script>
</body>
</html>
