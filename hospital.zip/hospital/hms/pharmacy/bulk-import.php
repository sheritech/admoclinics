<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['pharmaid'])==0){ header('location:index.php'); }

if(isset($_POST['submit'])){
  $file = $_FILES['csv_file']['name'];

  if(empty($file)){
    echo "<script>alert('Please select a CSV file');</script>";
  } else {
    $upload_dir = "uploads/";
    if(!is_dir($upload_dir)) mkdir($upload_dir);

    $target = $upload_dir . basename($file);
    if(move_uploaded_file($_FILES['csv_file']['tmp_name'], $target)){
      $handle = fopen($target, "r");
      $row = 0;
      $success = 0;
      $errors = [];

      while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $row++;
        if($row == 1) continue; // Skip header

        $name = trim($data[0]);
        $barcode = trim($data[1]);
        $quantity = trim($data[2]);
        $expiry_date = trim($data[3]);
        $mrp = trim($data[4]);
        $unit_price = trim($data[5]);

        if(empty($name) || empty($barcode) || empty($quantity) || empty($expiry_date) || empty($mrp)){
          $errors[] = "Row $row: Missing required fields";
          continue;
        }

        $sql = "INSERT INTO pharmacy_medicines (name,barcode,quantity,expiry_date,mrp,unit_price)
                VALUES ('$name','$barcode','$quantity','$expiry_date','$mrp','$unit_price')";
        if(mysqli_query($con, $sql)){
          $success++;
        } else {
          $errors[] = "Row $row: " . mysqli_error($con);
        }
      }
      fclose($handle);

      $message = "Import completed. $success medicines added.";
      if(!empty($errors)){
        $message .= " Errors: " . implode("; ", $errors);
      }
      echo "<script>alert('$message');</script>";
      echo "<script>window.location.href='medicines-list.php'</script>";
    } else {
      echo "<script>alert('Error uploading file');</script>";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pharmacy | Bulk Import Medicines</title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
  <link href="../assets/css/styles.css" rel="stylesheet">
  <link href="../assets/css/plugins.css" rel="stylesheet">
  <link href="../assets/css/themes/theme-1.css" rel="stylesheet" id="skin_color" />
</head>
<body>
<div id="app">
  <?php include('include/sidebar.php'); ?>
  <div class="app-content">
    <?php include('include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container" id="container">

        <section id="page-title">
          <div class="row">
            <div class="col-sm-8">
              <h1 class="mainTitle">Pharmacy | Bulk Import Medicines</h1>
            </div>
            <ol class="breadcrumb">
              <li><span>Pharmacy</span></li>
              <li class="active"><span>Bulk Import</span></li>
            </ol>
          </div>
        </section>

        <!-- Bulk Import Form -->
        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="panel panel-white">
                <div class="panel-heading">
                  <h5 class="panel-title">Bulk Import Medicines from CSV</h5>
                </div>
                <div class="panel-body">
                  <p><strong>CSV Format:</strong> name,barcode,quantity,expiry_date,mrp,unit_price</p>
                  <p><strong>Example:</strong></p>
                  <pre>Paracetamol,123456789,100,2025-12-31,10.50,8.00
Aspirin,987654321,50,2024-06-15,5.25,4.00</pre>
                  <form role="form" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                      <label for="csv_file">Select CSV File</label>
                      <input type="file" name="csv_file" class="form-control" accept=".csv" required>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary">
                      <i class="fa fa-upload"></i> Import Medicines
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End Bulk Import Form -->

      </div>
    </div>
  </div>
  <?php include('include/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../vendor/modernizr/modernizr.js"></script>
<script src="../vendor/jquery-cookie/jquery.cookie.js"></script>
<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="../vendor/switchery/switchery.min.js"></script>
<script src="../assets/js/main.js"></script>
<script>
  jQuery(document).ready(function() {
    Main.init();
  });
</script>
</body>
</html>