<div class="sidebar app-aside" id="sidebar">
    <div class="sidebar-container perfect-scrollbar">
        <nav>
            <!-- start: MAIN NAVIGATION MENU -->
            <div class="navbar-title">
                <span>Laboratory Navigation</span>
            </div>
            <ul class="main-navigation-menu">
                <!-- Dashboard -->
                <li>
                    <a href="dashboard.php">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-home"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Dashboard </span>
                            </div>
                        </div>
                    </a>
                </li>

                <!-- Test Catalog -->
                <li class="has-submenu">
                    <a href="javascript:void(0);">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-agenda"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Test Catalog </span>
                                <i class="ti-angle-down"></i>
                            </div>
                        </div>
                    </a>
                    <ul class="sub-menu">
                        <li>
                            <a href="catalog-add.php">
                                <span class="title"> Add New Test Type </span>
                            </a>
                        </li>
                        <li>
                            <a href="catalog-list.php">
                                <span class="title"> Manage Test Catalog </span>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Test Requests -->
                <li class="has-submenu">
                    <a href="javascript:void(0);">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-flask"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Test Requests </span>
                                <i class="ti-angle-down"></i>
                            </div>
                        </div>
                    </a>
                    <ul class="sub-menu">
                        <li>
                            <a href="test-add.php">
                                <span class="title"> New Test Request </span>
                            </a>
                        </li>
                        <li>
                            <a href="tests-list.php">
                                <span class="title"> List of Requests </span>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Results -->
                <li class="has-submenu">
                    <a href="javascript:void(0);">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-upload"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Results </span>
                                <i class="ti-angle-down"></i>
                            </div>
                        </div>
                    </a>
                    <ul class="sub-menu">
                        <li>
                            <a href="tests-list.php">
                                <span class="title"> Upload Result </span>
                            </a>
                        </li>
                        <li>
                            <a href="tests-list.php">
                                <span class="title"> View/Print Reports </span>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Clients -->
                <li>
                    <a href="clients-list.php">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-user"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Clients </span>
                            </div>
                        </div>
                    </a>
                </li>

                <!-- Staff Logs -->
                <li>
                    <a href="labstaff-logs.php">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-time"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Staff Logs </span>
                            </div>
                        </div>
                    </a>
                </li>

                <!-- Logout -->
                <li>
                    <a href="logout.php">
                        <div class="item-content">
                            <div class="item-media">
                                <i class="ti-power-off"></i>
                            </div>
                            <div class="item-inner">
                                <span class="title"> Logout </span>
                            </div>
                        </div>
                    </a>
                </li>
            </ul>
            <!-- end: CORE FEATURES -->
        </nav>
    </div>
</div>
