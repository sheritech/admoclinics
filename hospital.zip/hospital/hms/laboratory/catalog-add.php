<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['labid'])==0){ header('location:index.php'); }

// Handle form submission
if(isset($_POST['submit'])){
    $test_name = trim($_POST['test_name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $sample_type = trim($_POST['sample_type']);
    $normal_range = trim($_POST['normal_range']);

    if(empty($test_name) || empty($normal_range)){
        echo "<script>alert('Test name and normal range are required');</script>";
    } else {
        $sql = "INSERT INTO lab_test_types(test_name, description, price, sample_type, normal_range)
                VALUES('$test_name', '$description', '$price', '$sample_type', '$normal_range')";
        if(mysqli_query($con, $sql)){
            echo "<script>alert('Test type added successfully');</script>";
            echo "<script>window.location.href='catalog-list.php'</script>";
        } else {
            echo "<script>alert('Error adding test type');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Abiotech LAB | Add Test Type</title>
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<div id="app">
    <?php include('laboratory-sidebar.php'); ?>
    <div class="app-content">
        <?php include('../include/header.php'); ?>
        <div class="main-content">
            <div class="wrap-content container" id="container">

                <h1 class="mainTitle">Abiotech LAB | Add Test Type</h1>

                <!-- Add Test Type Form -->
                <div class="container-fluid container-fullw bg-white">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="panel panel-white">
                                <div class="panel-heading">
                                    <h5 class="panel-title">Add New Test Type</h5>
                                </div>
                                <div class="panel-body">
                                    <form method="post">
                                        <div class="form-group">
                                            <label for="test_name">Test Name *</label>
                                            <input type="text" name="test_name" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="description">Description</label>
                                            <textarea name="description" class="form-control" rows="3"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="price">Price</label>
                                            <input type="number" step="0.01" name="price" class="form-control" value="0.00">
                                        </div>
                                        <div class="form-group">
                                            <label for="sample_type">Sample Type</label>
                                            <input type="text" name="sample_type" class="form-control" placeholder="e.g., Blood, Urine">
                                        </div>
                                        <div class="form-group">
                                            <label for="normal_range">Normal Range *</label>
                                            <input type="text" name="normal_range" class="form-control" placeholder="e.g., 70-100 mg/dL" required>
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-success">
                                            <i class="fa fa-plus"></i> Add Test Type
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Form -->

            </div>
        </div>
    </div>
    <?php include('../include/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        // Any JS if needed
    });
</script>
</body>
</html>