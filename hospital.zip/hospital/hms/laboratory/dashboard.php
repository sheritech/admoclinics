<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['labid'])==0){
  header('location:index.php');
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Abiotech LAB | Dashboard</title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
  <link href="../assets/css/styles.css" rel="stylesheet">
  <link href="../assets/css/plugins.css" rel="stylesheet">
  <link href="../assets/css/themes/theme-1.css" rel="stylesheet" id="skin_color" />
</head>
<body>
<div id="app">		
  <?php include('laboratory-sidebar.php'); ?>
  <div class="app-content">
    <?php include('../include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container" id="container">

        <section id="page-title">
          <div class="row">
            <div class="col-sm-8">
              <h1 class="mainTitle">Abiotech LAB | Dashboard</h1>
            </div>
            <ol class="breadcrumb">
              <li><span>Laboratory</span></li>
              <li class="active"><span>Dashboard</span></li>
            </ol>
          </div>
        </section>

        <!-- Dashboard Tiles -->
        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <?php
            $total_tests = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(*) as count FROM lab_tests"))['count'];
            $pending_tests = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(*) as count FROM lab_tests WHERE status='Pending'"))['count'];
            $in_progress_tests = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(*) as count FROM lab_tests WHERE status='In Progress'"))['count'];
            $completed_tests = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(*) as count FROM lab_tests WHERE status='Completed'"))['count'];
            $delivered_tests = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(*) as count FROM lab_tests WHERE status='Delivered'"))['count'];
            ?>
            <div class="col-sm-3">
              <div class="panel panel-white no-radius text-center">
                <div class="panel-body">
                  <span class="fa-stack fa-2x">
                    <i class="fa fa-square fa-stack-2x text-primary"></i>
                    <i class="fa fa-flask fa-stack-1x fa-inverse"></i>
                  </span>
                  <h2 class="StepTitle"><?php echo $total_tests; ?></h2>
                  <p class="text-muted">Total Tests</p>
                  <p class="links cl-effect-1">
                    <a href="tests-list.php">View All</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="panel panel-white no-radius text-center">
                <div class="panel-body">
                  <span class="fa-stack fa-2x">
                    <i class="fa fa-square fa-stack-2x text-warning"></i>
                    <i class="fa fa-clock-o fa-stack-1x fa-inverse"></i>
                  </span>
                  <h2 class="StepTitle"><?php echo $pending_tests; ?></h2>
                  <p class="text-muted">Pending</p>
                  <p class="links cl-effect-1">
                    <a href="tests-list.php">Manage</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="panel panel-white no-radius text-center">
                <div class="panel-body">
                  <span class="fa-stack fa-2x">
                    <i class="fa fa-square fa-stack-2x text-info"></i>
                    <i class="fa fa-spinner fa-stack-1x fa-inverse"></i>
                  </span>
                  <h2 class="StepTitle"><?php echo $in_progress_tests; ?></h2>
                  <p class="text-muted">In Progress</p>
                  <p class="links cl-effect-1">
                    <a href="tests-list.php">Update</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="panel panel-white no-radius text-center">
                <div class="panel-body">
                  <span class="fa-stack fa-2x">
                    <i class="fa fa-square fa-stack-2x text-info"></i>
                    <i class="fa fa-spinner fa-stack-1x fa-inverse"></i>
                  </span>
                  <h2 class="StepTitle"><?php echo $in_progress_tests; ?></h2>
                  <p class="text-muted">In Progress</p>
                  <p class="links cl-effect-1">
                    <a href="tests-list.php">Update</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="panel panel-white no-radius text-center">
                <div class="panel-body">
                  <span class="fa-stack fa-2x">
                    <i class="fa fa-square fa-stack-2x text-success"></i>
                    <i class="fa fa-check fa-stack-1x fa-inverse"></i>
                  </span>
                  <h2 class="StepTitle"><?php echo $completed_tests; ?></h2>
                  <p class="text-muted">Completed</p>
                  <p class="links cl-effect-1">
                    <a href="tests-list.php">View Reports</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="panel panel-white no-radius text-center">
                <div class="panel-body">
                  <span class="fa-stack fa-2x">
                    <i class="fa fa-square fa-stack-2x text-primary"></i>
                    <i class="fa fa-truck fa-stack-1x fa-inverse"></i>
                  </span>
                  <h2 class="StepTitle"><?php echo $delivered_tests; ?></h2>
                  <p class="text-muted">Delivered</p>
                  <p class="links cl-effect-1">
                    <a href="tests-list.php">View All</a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End Dashboard Tiles -->

        <!-- Recent Tests -->
        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <div class="col-md-12">
              <div class="panel panel-white">
                <div class="panel-heading">
                  <h5 class="panel-title">Recent Tests</h5>
                </div>
                <div class="panel-body">
                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Test ID</th>
                        <th>Client</th>
                        <th>Test Name</th>
                        <th>Date</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $recent = mysqli_query($con, "
                        SELECT t.test_id,
                               COALESCE(p.PatientName, c.ClientName) AS ClientName,
                               t.test_name,
                               t.test_date,
                               t.status
                        FROM lab_tests t
                        LEFT JOIN tblpatient p ON t.patient_id = p.ID
                        LEFT JOIN tblclient_external c ON t.client_id = c.id
                        ORDER BY t.test_date DESC LIMIT 10
                      ");
                      while($row = mysqli_fetch_array($recent)){ ?>
                      <tr>
                        <td><?php echo $row['test_id']; ?></td>
                        <td><?php echo htmlentities($row['ClientName']); ?></td>
                        <td><?php echo htmlentities($row['test_name']); ?></td>
                        <td><?php echo $row['test_date']; ?></td>
                        <td>
                          <?php if($row['status']=='Completed'){ ?>
                            <span class="label label-success">Completed</span>
                          <?php } elseif($row['status']=='Delivered'){ ?>
                            <span class="label label-primary">Delivered</span>
                          <?php } elseif($row['status']=='In Progress'){ ?>
                            <span class="label label-info">In Progress</span>
                          <?php } else { ?>
                            <span class="label label-warning"><?php echo $row['status']; ?></span>
                          <?php } ?>
                        </td>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End Recent Tests -->

      </div>
    </div>
  </div>
  <?php include('../include/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../vendor/modernizr/modernizr.js"></script>
<script src="../vendor/jquery-cookie/jquery.cookie.js"></script>
<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="../vendor/switchery/switchery.min.js"></script>
<script src="../assets/js/main.js"></script>
<script>
  jQuery(document).ready(function() {
    Main.init();
  });
</script>
</body>
</html>
<?php } ?>
