<?php
session_start();
include('../include/config.php');

if(strlen($_SESSION['labid'])==0){
    echo "Unauthorized access";
    exit;
}

if(isset($_POST['test_id']) && isset($_POST['status'])){
    $test_id = intval($_POST['test_id']);
    $status = mysqli_real_escape_string($con, $_POST['status']);

    $valid_statuses = ['Pending', 'In Progress', 'Completed', 'Delivered'];
    if(!in_array($status, $valid_statuses)){
        echo "Invalid status";
        exit;
    }

    $query = "UPDATE lab_tests SET status='$status' WHERE test_id=$test_id";
    if(mysqli_query($con, $query)){
        echo "success";
    } else {
        echo "Database error: " . mysqli_error($con);
    }
} else {
    echo "Missing parameters";
}
?>