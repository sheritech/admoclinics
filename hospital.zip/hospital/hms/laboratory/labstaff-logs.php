<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['labid'])==0){ header('location:index.php'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Abiotech LAB | Staff Logs</title>
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
    <link href="../vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="../vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="../vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="../assets/css/styles.css" rel="stylesheet">
    <link href="../assets/css/plugins.css" rel="stylesheet">
    <link href="../assets/css/themes/theme-1.css" rel="stylesheet" id="skin_color" />
</head>
<body>
<div id="app">
    <?php include('laboratory-sidebar.php'); ?>
    <div class="app-content">
        <?php include('../include/header.php'); ?>
        <div class="main-content">
            <div class="wrap-content container" id="container">

                <section id="page-title">
                    <div class="row">
                        <div class="col-sm-8">
                            <h1 class="mainTitle">Abiotech LAB | Staff Session Logs</h1>
                        </div>
                        <ol class="breadcrumb">
                            <li><span>Laboratory</span></li>
                            <li class="active"><span>Logs</span></li>
                        </ol>
                    </div>
                </section>

                <!-- Logs Table -->
                <div class="container-fluid container-fullw bg-white">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-white">
                                <div class="panel-heading">
                                    <h5 class="panel-title">Login/Logout History</h5>
                                </div>
                                <div class="panel-body">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Staff Name</th>
                                                <th>Username</th>
                                                <th>IP Address</th>
                                                <th>Login Time</th>
                                                <th>Logout Time</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $ret = mysqli_query($con, "
                                                SELECT l.*, s.Username as StaffName
                                                FROM labstafflog l
                                                LEFT JOIN tbllabstaff s ON l.uid = s.ID
                                                ORDER BY l.loginTime DESC
                                            ");
                                            while($row = mysqli_fetch_array($ret)){ ?>
                                            <tr>
                                                <td><?php echo htmlentities($row['StaffName'] ?: $row['username']); ?></td>
                                                <td><?php echo htmlentities($row['username']); ?></td>
                                                <td><?php echo htmlentities($row['userip']); ?></td>
                                                <td><?php echo $row['loginTime']; ?></td>
                                                <td><?php echo $row['logoutTime'] ?: 'Active'; ?></td>
                                                <td>
                                                    <?php if($row['status'] == 1){ ?>
                                                        <span class="label label-success">Success</span>
                                                    <?php } else { ?>
                                                        <span class="label label-danger">Failed</span>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Table -->

            </div>
        </div>
    </div>
    <?php include('../include/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../vendor/modernizr/modernizr.js"></script>
<script src="../vendor/jquery-cookie/jquery.cookie.js"></script>
<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="../vendor/switchery/switchery.min.js"></script>
<script src="../assets/js/main.js"></script>
<script>
    jQuery(document).ready(function() {
        Main.init();
    });
</script>
</body>
</html>