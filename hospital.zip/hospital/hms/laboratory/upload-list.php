<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['labid'])==0){ header('location:index.php'); }

$testid = intval($_GET['id']);

// Fetch full report info
$q = mysqli_query($con,"
SELECT t.test_id, t.test_name, t.test_date, t.status, t.reference_range,
       p.PatientName, p.PatientAge, p.PatientGender,
       c.ClientName, c.contact as ClientContact,
       d.doctorName,
       r.result_value, r.result_notes, r.result_file, r.created_at
FROM lab_tests t
LEFT JOIN tblpatient p ON t.patient_id=p.ID
LEFT JOIN tblclient_external c ON t.client_id=c.id
LEFT JOIN doctors d ON t.doctor_id=d.id
LEFT JOIN lab_results r ON t.test_id=r.test_id
WHERE t.test_id=$testid
");

$data = mysqli_fetch_array($q);
if(!$data){
    die("❌ Test not found or no results uploaded yet. <a href='tests-list.php'>Back</a>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Lab Report #<?php echo $data['test_id']; ?></title>
  <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet">
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../assets/css/styles.css">
  <style>
    .report-box { max-width: 900px; margin: auto; padding: 20px; border: 1px solid #ccc; background: #fff; }
    .report-header { text-align: center; margin-bottom: 20px; }
    .report-header h2 { margin: 0; color: #007bff; }
    .report-section { margin-bottom: 20px; }
    .report-section h4 { border-bottom: 1px solid #ddd; padding-bottom: 5px; margin-bottom: 10px; }
    .table th { background: #f8f9fa; }
    .signature { margin-top: 50px; display: flex; justify-content: space-between; }
    .signature div { text-align: center; width: 40%; }
    @media print {
      .btn, .sidebar, .app-footer { display: none !important; }
      body { font-size: 12px; }
      .report-box { border: none; margin: 0; }
    }
  </style>
</head>
<body>
<div id="app">
  <?php include('laboratory-sidebar.php'); ?>
  <div class="app-content">
    <?php include('../include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container">

        <div class="report-box">
          <div class="report-header">
            <h2>Abiotech Lab</h2>
            <small>Generated on <?php echo date('d-m-Y H:i:s'); ?></small>
          </div>

          <!-- Report Info -->
          <div class="report-section">
            <h4>Report Info</h4>
            <p><b>Report ID:</b> #<?php echo str_pad($data['test_id'], 6, '0', STR_PAD_LEFT); ?></p>
            <p><b>Test Name:</b> <?php echo $data['test_name']; ?></p>
            <p><b>Test Date:</b> <?php echo date('d-m-Y', strtotime($data['test_date'])); ?></p>
            <p><b>Status:</b> <?php echo $data['status']; ?></p>
          </div>

          <!-- Patient / Client Info -->
          <div class="report-section">
            <h4>Patient / Client Information</h4>
            <?php if($data['PatientName']){ ?>
              <p><b>Name:</b> <?php echo $data['PatientName']; ?></p>
              <p><b>Age:</b> <?php echo $data['PatientAge']; ?></p>
              <p><b>Gender:</b> <?php echo $data['PatientGender']; ?></p>
              <p><b>Doctor:</b> <?php echo $data['doctorName'] ?: 'N/A'; ?></p>
              <p><b>Type:</b> Hospital Patient</p>
            <?php } else { ?>
              <p><b>Name:</b> <?php echo $data['ClientName']; ?></p>
              <p><b>Contact:</b> <?php echo $data['ClientContact']; ?></p>
              <p><b>Type:</b> External Client</p>
            <?php } ?>
          </div>

          <!-- Results -->
          <div class="report-section">
            <h4>Test Results</h4>
            <p><b>Reference Range:</b> <?php echo $data['reference_range']; ?></p>
            <p><b>Result:</b> <?php echo $data['result_value'] ?: 'Pending'; ?></p>
            <?php if($data['result_notes']){ ?>
              <p><b>Notes:</b><br><?php echo nl2br($data['result_notes']); ?></p>
            <?php } ?>
            <?php if($data['result_file']){ ?>
              <p><b>Attached File:</b> <a href="<?php echo $data['result_file']; ?>" target="_blank"><i class="fa fa-file-pdf-o"></i> View PDF</a></p>
            <?php } ?>
          </div>

          <!-- Signature -->
          <div class="signature">
            <div>
              ______________________<br>
              Lab Technician<br>
              Date: <?php echo date('d-m-Y'); ?>
            </div>
            <div>
              ______________________<br>
              Lab Director<br>
              Date: <?php echo date('d-m-Y'); ?>
            </div>
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="text-center" style="margin-top:20px;">
          <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print Report</button>
          <a href="tests-list.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> Back</a>
        </div>

      </div>
    </div>
  </div>
  <?php include('../include/footer.php'); ?>
</div>
</body>
</html>
