<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['labid'])==0){ header('location:index.php'); }

// Handle Edit
if(isset($_POST['edit'])){
    $type_id = intval($_POST['type_id']);
    $test_name = trim($_POST['test_name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $sample_type = trim($_POST['sample_type']);
    $normal_range = trim($_POST['normal_range']);

    if(empty($test_name) || empty($normal_range)){
        echo "<script>alert('Test name and normal range are required');</script>";
    } else {
        mysqli_query($con, "UPDATE lab_test_types SET test_name='$test_name', description='$description', price='$price', sample_type='$sample_type', normal_range='$normal_range' WHERE type_id=$type_id");
        echo "<script>alert('Test type updated successfully');</script>";
    }
}

// Handle Delete
if(isset($_GET['del'])){
    $type_id = intval($_GET['del']);
    mysqli_query($con, "DELETE FROM lab_test_types WHERE type_id=$type_id");
    echo "<script>alert('Test type deleted successfully');</script>";
    echo "<script>window.location.href='catalog-list.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Abiotech LAB | Test Catalog</title>
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
    <link href="../vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="../vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="../vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="../assets/css/styles.css" rel="stylesheet">
    <link href="../assets/css/plugins.css" rel="stylesheet">
    <link href="../assets/css/themes/theme-1.css" rel="stylesheet" id="skin_color" />
</head>
<body>
<div id="app">
    <?php include('laboratory-sidebar.php'); ?>
    <div class="app-content">
        <?php include('../include/header.php'); ?>
        <div class="main-content">
            <div class="wrap-content container" id="container">

                <section id="page-title">
                    <div class="row">
                        <div class="col-sm-8">
                            <h1 class="mainTitle">Abiotech LAB | Test Catalog</h1>
                        </div>
                        <ol class="breadcrumb">
                            <li><span>Laboratory</span></li>
                            <li class="active"><span>Test Catalog</span></li>
                        </ol>
                    </div>
                </section>

                <!-- Test Types Table -->
                <div class="container-fluid container-fullw bg-white">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-white">
                                <div class="panel-heading">
                                    <h5 class="panel-title">Test Types List</h5>
                                    <div class="text-right">
                                        <a href="catalog-add.php" class="btn btn-primary btn-sm">
                                            <i class="fa fa-plus"></i> Add Test Type
                                        </a>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Test Name</th>
                                                <th>Description</th>
                                                <th>Price</th>
                                                <th>Sample Type</th>
                                                <th>Normal Range</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $ret = mysqli_query($con, "SELECT * FROM lab_test_types ORDER BY test_name");
                                            while($row = mysqli_fetch_array($ret)){ ?>
                                            <tr>
                                                <td><?php echo $row['type_id']; ?></td>
                                                <td><?php echo htmlentities($row['test_name']); ?></td>
                                                <td><?php echo htmlentities($row['description']); ?></td>
                                                <td><?php echo $row['price']; ?></td>
                                                <td><?php echo htmlentities($row['sample_type']); ?></td>
                                                <td><?php echo htmlentities($row['normal_range']); ?></td>
                                                <td>
                                                    <button class="btn btn-sm btn-warning" data-toggle="modal" data-target="#editModal"
                                                            onclick="editType(<?php echo $row['type_id']; ?>, '<?php echo addslashes($row['test_name']); ?>', '<?php echo addslashes($row['description']); ?>', '<?php echo $row['price']; ?>', '<?php echo addslashes($row['sample_type']); ?>', '<?php echo addslashes($row['normal_range']); ?>')">
                                                        <i class="fa fa-edit"></i> Edit
                                                    </button>
                                                    <a href="catalog-list.php?del=<?php echo $row['type_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                                        <i class="fa fa-trash"></i> Delete
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Table -->

            </div>
        </div>
    </div>
    <?php include('../include/footer.php'); ?>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Test Type</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="post">
                <input type="hidden" name="type_id" id="edit_type_id">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Test Name *</label>
                        <input type="text" name="test_name" id="edit_test_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Price</label>
                        <input type="number" step="0.01" name="price" id="edit_price" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Sample Type</label>
                        <input type="text" name="sample_type" id="edit_sample_type" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Normal Range *</label>
                        <input type="text" name="normal_range" id="edit_normal_range" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="edit" class="btn btn-success">Update</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../vendor/modernizr/modernizr.js"></script>
<script src="../vendor/jquery-cookie/jquery.cookie.js"></script>
<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="../vendor/switchery/switchery.min.js"></script>
<script src="../assets/js/main.js"></script>
<script>
    jQuery(document).ready(function() {
        Main.init();
    });

    function editType(type_id, test_name, description, price, sample_type, normal_range) {
        document.getElementById('edit_type_id').value = type_id;
        document.getElementById('edit_test_name').value = test_name;
        document.getElementById('edit_description').value = description;
        document.getElementById('edit_price').value = price;
        document.getElementById('edit_sample_type').value = sample_type;
        document.getElementById('edit_normal_range').value = normal_range;
    }
</script>
</body>
</html>