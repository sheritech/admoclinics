<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['labid'])==0){ header('location:index.php'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Abiotech LAB | Tests List</title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
  <link href="../vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
  <link href="../assets/css/styles.css" rel="stylesheet">
  <link href="../assets/css/plugins.css" rel="stylesheet">
  <link href="../assets/css/themes/theme-1.css" rel="stylesheet" id="skin_color" />
</head>
<body>
<div id="app">
  <?php include('laboratory-sidebar.php'); ?>
  <div class="app-content">
    <?php include('../include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container" id="container">

        <section id="page-title">
          <div class="row">
            <div class="col-sm-8">
              <h1 class="mainTitle">Abiotech LAB | Tests List</h1>
            </div>
            <ol class="breadcrumb">
              <li><span>Laboratory</span></li>
              <li class="active"><span>Tests</span></li>
            </ol>
          </div>
        </section>

        <!-- Tests Table -->
        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <div class="col-md-12">
              <div class="panel panel-white">
                <div class="panel-heading">
                  <h5 class="panel-title">All Lab Tests</h5>
                  <div class="text-right">
                    <a href="test-add.php" class="btn btn-primary btn-sm">
                      <i class="fa fa-plus"></i> Add Test
                    </a>
                  </div>
                </div>
                <div class="panel-body">
                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Client</th>
                        <th>Test</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $ret = mysqli_query($con,"
                        SELECT t.test_id,
                               COALESCE(p.PatientName, c.ClientName) AS ClientName,
                               CASE WHEN t.patient_id IS NOT NULL THEN 'Patient' ELSE 'External' END AS ClientType,
                               t.test_name AS TestName,
                               t.test_date,
                               t.status
                        FROM lab_tests t
                        LEFT JOIN tblpatient p ON t.patient_id = p.ID
                        LEFT JOIN tblclient_external c ON t.client_id = c.id
                        ORDER BY t.test_date DESC
                      ");
                      while($row=mysqli_fetch_array($ret)){ ?>
                      <tr>
                        <td><?php echo $row['test_id']; ?></td>
                        <td><?php echo htmlentities($row['ClientName']); ?> (<?php echo $row['ClientType']; ?>)</td>
                        <td><?php echo htmlentities($row['TestName']); ?></td>
                        <td><?php echo $row['test_date']; ?></td>
                        <td>
                          <?php if($row['status']=='Completed'){ ?>
                            <span class="label label-success">Completed</span>
                          <?php } else { ?>
                            <span class="label label-warning"><?php echo $row['status']; ?></span>
                          <?php } ?>
                        </td>
                        <td>
                          <?php if($row['status']!='Completed'){ ?>
                            <a href="results-upload.php?id=<?php echo $row['test_id'];?>" class="btn btn-sm btn-info">
                              <i class="fa fa-upload"></i> Upload Result
                            </a>
                          <?php } else { ?>
                            <a href="upload-list.php?id=<?php echo $row['test_id'];?>" class="btn btn-sm btn-success">
                              <i class="fa fa-file-text"></i> View Report
                            </a>
                          <?php } ?>
                          <div class="btn-group" style="margin-top:5px;">
                            <button type="button" class="btn btn-sm btn-warning dropdown-toggle" data-toggle="dropdown">
                              <i class="fa fa-cog"></i> Actions <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                              <li><a href="#" onclick="changeStatus(<?php echo $row['test_id']; ?>, 'In Progress')"><i class="fa fa-play"></i> Mark In Progress</a></li>
                              <li><a href="#" onclick="changeStatus(<?php echo $row['test_id']; ?>, 'Completed')"><i class="fa fa-check"></i> Mark Completed</a></li>
                              <li><a href="#" onclick="changeStatus(<?php echo $row['test_id']; ?>, 'Delivered')"><i class="fa fa-truck"></i> Mark Delivered</a></li>
                              <li class="divider"></li>
                              <li><a href="#" onclick="deleteTest(<?php echo $row['test_id']; ?>)" style="color:red;"><i class="fa fa-trash"></i> Delete Test</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End Tests Table -->

      </div>
    </div>
  </div>
  <?php include('../include/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/main.js"></script>
<script>
  jQuery(document).ready(function() {
    Main.init();
  });

  function changeStatus(testId, newStatus) {
    if(confirm('Are you sure you want to change the status to "' + newStatus + '"?')) {
      $.post('update_test_status.php', {test_id: testId, status: newStatus}, function(response) {
        if(response == 'success') {
          alert('Status updated successfully');
          location.reload();
        } else {
          alert('Error updating status: ' + response);
        }
      });
    }
  }

  function deleteTest(testId) {
    if(confirm('Are you sure you want to delete this test? This action cannot be undone.')) {
      $.post('delete_test.php', {test_id: testId}, function(response) {
        if(response == 'success') {
          alert('Test deleted successfully');
          location.reload();
        } else {
          alert('Error deleting test: ' + response);
        }
      });
    }
  }
</script>
</body>
</html>
