<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['labid'])==0){ header('location:index.php'); }

// ✅ Guard against missing test ID
if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
    die("❌ No Test ID provided. Please go back to <a href='tests-list.php'>Tests List</a>.");
}

$testid = intval($_GET['id']); // lab_tests.test_id

// Include result templates
include('result-templates.php');

if(isset($_POST['submit'])){
  $value = trim($_POST['result_value']);
  $notes = trim($_POST['result_notes']);
  $entry_method = $_POST['entry_method'];
  $final_status = $_POST['final_status'];
  $template = $_POST['test_template'];
  $file = $_FILES['result_file']['name'];

  if(empty($value)){
      echo "<script>alert('Result value is required');</script>";
  } elseif($entry_method == 'file' && empty($file)){
      echo "<script>alert('Please upload a result file');</script>";
  } else {
      $target = null;
      $detailed_results = '';

      // Handle template parameters
      if(!empty($template) && isset($result_templates[$template])){
        $template_data = $result_templates[$template];
        $detailed_results = "Test: " . $template_data['name'] . "\n\nParameters:\n";

        foreach($template_data['parameters'] as $param => $data){
          $param_key = 'param_' . str_replace(' ', '_', $param);
          $param_value = trim($_POST[$param_key] ?? '');
          if(!empty($param_value)){
            $detailed_results .= "- $param: $param_value {$data['unit']} (Normal: {$data['normal_range']})\n";
          }
        }
        $detailed_results .= "\n";
      }

      // Handle file upload if provided
      if(!empty($file)){
          $upload_dir = "uploads/";
          if(!is_dir($upload_dir)) mkdir($upload_dir);

          $target = $upload_dir . basename($file);
          if(!move_uploaded_file($_FILES['result_file']['tmp_name'], $target)){
              echo "<script>alert('Error uploading file');</script>";
              exit;
          }
      }

      // Combine notes with detailed results
      $full_notes = $detailed_results . $notes;

      // Insert into lab_results
      $sql = "INSERT INTO lab_results(test_id,result_value,result_notes,result_file)
              VALUES('$testid','$value','$full_notes',".($target ? "'$target'" : "NULL").")";
      mysqli_query($con, $sql);

      // Update lab_tests status
      mysqli_query($con, "UPDATE lab_tests SET status='$final_status' WHERE test_id=$testid");

      echo "<script>alert('Result saved successfully');</script>";
      echo "<script>window.location.href='tests-list.php'</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Abiotech LAB | Upload Result</title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../assets/css/styles.css" rel="stylesheet">
</head>
<body>
<div id="app">
  <?php include('laboratory-sidebar.php'); ?>
  <div class="app-content">
    <?php include('../include/header.php'); ?>
    <div class="main-content">
      <div class="wrap-content container" id="container">

        <section id="page-title">
          <div class="row">
            <div class="col-sm-8">
              <h1 class="mainTitle">Abiotech LAB | Upload Result</h1>
            </div>
            <ol class="breadcrumb">
              <li><span>Laboratory</span></li>
              <li class="active"><span>Upload Result</span></li>
            </ol>
          </div>
        </section>

        <!-- Upload Result Form -->
        <div class="container-fluid container-fullw bg-white">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="panel panel-white">
                <div class="panel-heading">
                  <h5 class="panel-title">Upload Test Result</h5>
                </div>
                <div class="panel-body">
                  <div class="alert alert-info">
                    <strong>Choose Result Entry Method:</strong> You can either enter results directly or upload a PDF file.
                  </div>

                  <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                      <label>Test Template (Optional)</label>
                      <select name="test_template" class="form-control" onchange="loadTemplate(this.value)">
                        <option value="">Select a template or enter manually</option>
                        <?php foreach($result_templates as $key => $template): ?>
                        <option value="<?php echo $key; ?>"><?php echo $template['name']; ?></option>
                        <?php endforeach; ?>
                      </select>
                    </div>

                    <div id="template_parameters" style="display:none;">
                      <h4>Template Parameters</h4>
                      <div id="parameters_container"></div>
                    </div>

                    <div class="form-group">
                      <label for="result_value">Result Value/Summary *</label>
                      <input type="text" name="result_value" class="form-control" placeholder="e.g., Positive, 120 mg/dL, Normal Range">
                      <small class="text-muted">Enter a summary result or select a template above</small>
                    </div>
                    <div class="form-group">
                      <label for="result_notes">Detailed Notes</label>
                      <textarea name="result_notes" class="form-control" rows="4" placeholder="Additional observations, reference ranges, interpretations..."></textarea>
                    </div>

                    <div class="form-group">
                      <label>Result Entry Method</label><br>
                      <input type="radio" name="entry_method" value="direct" checked onclick="toggleFileUpload(false)"> Direct Entry Only
                      <input type="radio" name="entry_method" value="file" style="margin-left:20px;" onclick="toggleFileUpload(true)"> Upload PDF File
                    </div>

                    <div class="form-group" id="file_upload_group" style="display:none;">
                      <label for="result_file">Result File (PDF)</label>
                      <input type="file" name="result_file" class="form-control" accept="application/pdf">
                      <small class="text-muted">Optional: Upload a detailed PDF report</small>
                    </div>

                    <div class="form-group">
                      <label>Test Status After Entry</label><br>
                      <input type="radio" name="final_status" value="Completed" checked> Mark as Completed
                      <input type="radio" name="final_status" value="In Progress" style="margin-left:20px;"> Keep as In Progress
                    </div>

                    <button type="submit" name="submit" class="btn btn-success btn-lg">
                      <i class="fa fa-save"></i> Save Results
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End Form -->

      </div>
    </div>
  </div>
  <?php include('../include/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/main.js"></script>
<script>
  jQuery(document).ready(function() {
    Main.init();
  });

  function toggleFileUpload(show) {
    if(show) {
      document.getElementById('file_upload_group').style.display = 'block';
    } else {
      document.getElementById('file_upload_group').style.display = 'none';
    }
  }

  function loadTemplate(templateKey) {
    const container = document.getElementById('parameters_container');
    const templateDiv = document.getElementById('template_parameters');

    if(!templateKey) {
      templateDiv.style.display = 'none';
      container.innerHTML = '';
      return;
    }

    const templates = <?php echo json_encode($result_templates); ?>;
    const template = templates[templateKey];

    if(template) {
      let html = '<table class="table table-bordered"><thead><tr><th>Parameter</th><th>Result</th><th>Unit</th><th>Normal Range</th></tr></thead><tbody>';

      Object.keys(template.parameters).forEach(param => {
        const data = template.parameters[param];
        html += `<tr>
          <td>${param}</td>
          <td><input type="text" class="form-control" name="param_${param.replace(/\s+/g, '_')}" placeholder="Enter result"></td>
          <td>${data.unit}</td>
          <td>${data.normal_range}</td>
        </tr>`;
      });

      html += '</tbody></table>';
      container.innerHTML = html;
      templateDiv.style.display = 'block';

      // Scroll to the template parameters section
      setTimeout(() => {
        templateDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  }
</script>
</body>
</html>
