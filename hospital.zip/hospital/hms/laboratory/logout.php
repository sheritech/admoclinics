<?php
session_start();
include('../include/config.php');

if(isset($_SESSION['labid'])){
    $log_id = $_SESSION['lab_log_id'] ?? 0;
    if($log_id>0){
        mysqli_query($con,"UPDATE labstafflog SET logout_time=NOW() WHERE id=$log_id");
    }
}
session_unset();
session_destroy();
header('location:index.php');
?>
