<?php
session_start();
include('../include/config.php');

if(isset($_POST['login'])){
    $uname = $_POST['username'];
    $password = $_POST['password'];
    $uip = $_SERVER['REMOTE_ADDR'];

    $query = mysqli_query($con,"SELECT ID FROM tbllabstaff WHERE Username='$uname' AND Password='$password'");

    if(mysqli_num_rows($query) > 0){
        $num = mysqli_fetch_array($query);
        $_SESSION['labid']=$num['ID'];

        $log_query = "INSERT INTO labstafflog(uid,username,userip,status) VALUES('".$num['ID']."','$uname','$uip','1')";
        mysqli_query($con, $log_query);
        $_SESSION['lab_log_id'] = mysqli_insert_id($con);

        header("location:dashboard.php");
        exit;
    } else {
        echo "<script>alert('Invalid username or password');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Abiotech LAB | Login</title>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../vendor/themify-icons/themify-icons.min.css">
  <link href="../assets/css/styles.css" rel="stylesheet">
  <style>
    body {
      background:#f7f7f7;
    }
    .login-box {
      margin-top:80px;
      max-width:400px;
      background:#fff;
      padding:30px;
      border-radius:10px;
      box-shadow:0 0 15px rgba(0,0,0,0.2);
    }
    .login-box h2 {
      margin-bottom:20px;
      text-align:center;
      font-weight:600;
    }
  </style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-4 col-md-offset-4">
      <div class="login-box">
        <h2><i class="fa fa-flask text-primary"></i> Laboratory Login</h2>
        <form method="post">
          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required autofocus>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <button type="submit" name="login" class="btn btn-primary btn-block">
            <i class="fa fa-sign-in"></i> Login
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/main.js"></script>
</body>
</html>
