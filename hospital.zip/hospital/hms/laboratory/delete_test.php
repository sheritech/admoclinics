<?php
session_start();
include('../include/config.php');

if(strlen($_SESSION['labid'])==0){
    echo "Unauthorized access";
    exit;
}

if(isset($_POST['test_id'])){
    $test_id = intval($_POST['test_id']);

    // First delete any associated results
    mysqli_query($con, "DELETE FROM lab_results WHERE test_id=$test_id");

    // Then delete the test
    $query = "DELETE FROM lab_tests WHERE test_id=$test_id";
    if(mysqli_query($con, $query)){
        echo "success";
    } else {
        echo "Database error: " . mysqli_error($con);
    }
} else {
    echo "Missing test ID";
}
?>