<?php
session_start();
include('../include/config.php');
if(strlen($_SESSION['labid'])==0){ header('location:index.php'); }

// Handle form submission
if(isset($_POST['submit'])){
    $type_id = $_POST['type_id'];
    $test_date = $_POST['test_date'];
    $client_type = $_POST['client_type'];
    $patient_id = null;
    $client_id = null;
    $doctor_id = null;

    if(empty($type_id) || empty($test_date)){
        echo "<script>alert('Please select a test and date');</script>";
    } elseif($client_type == 'patient' && empty($_POST['patient_id'])){
        echo "<script>alert('Please select a patient');</script>";
    } elseif($client_type == 'external' && empty($_POST['client_id'])){
        echo "<script>alert('Please select an external client');</script>";
    } else {
        if($client_type == 'patient'){
            $patient_id = $_POST['patient_id'];
            $doctor_id = $_POST['doctor_id'];
        } else {
            $client_id = $_POST['client_id'];
        }

        // Fetch test name and reference range from lab_test_types
        $qTest = mysqli_query($con,"SELECT test_name, normal_range FROM lab_test_types WHERE type_id='$type_id'");
        $testRow = mysqli_fetch_array($qTest);
        $test_name = $testRow['test_name'];
        $reference_range = $testRow['normal_range'];

        $sql = "INSERT INTO lab_tests(type_id, test_name, reference_range, test_date, patient_id, client_id, doctor_id, status, created_at)
                VALUES('$type_id', '$test_name', '$reference_range', '$test_date', ".($patient_id ? "'$patient_id'" : "NULL").", ".($client_id ? "'$client_id'" : "NULL").", ".($doctor_id ? "'$doctor_id'" : "NULL").", 'Pending', NOW())";
        if(mysqli_query($con, $sql)){
            echo "<script>alert('Test request added successfully');</script>";
            echo "<script>window.location.href='tests-list.php'</script>";
        } else {
            echo "<script>alert('Error adding test');</script>";
        }
    }
}

// Fetch test types
$test_types = mysqli_query($con, "SELECT type_id, test_name, price, normal_range FROM lab_test_types ORDER BY test_name");

// Fetch patients
$patients = mysqli_query($con, "SELECT ID, PatientName FROM tblpatient ORDER BY PatientName");

// Fetch external clients
$clients = mysqli_query($con, "SELECT id, ClientName as name FROM tblclient_external ORDER BY ClientName");

// Fetch doctors
$doctors = mysqli_query($con, "SELECT id, doctorName FROM doctors ORDER BY doctorName");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Abiotech LAB | Add Test</title>
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<div id="app">
    <?php include('laboratory-sidebar.php'); ?>
    <div class="app-content">
        <?php include('../include/header.php'); ?>
        <div class="main-content">
            <div class="wrap-content container" id="container">

                <h1 class="mainTitle">Abiotech LAB | Add Test</h1>

                <!-- Add Test Form -->
                <div class="container-fluid container-fullw bg-white">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="panel panel-white">
                                <div class="panel-heading">
                                    <h5 class="panel-title">Add New Test Request</h5>
                                </div>
                                <div class="panel-body">
                                    <form method="post">
                                        <div class="form-group">
                                            <label for="catalog_id">Select Test</label>
                                            <select name="type_id" id="type_id" class="form-control" required>
                                                <option value="">Select Test</option>
                                                <?php while($t = mysqli_fetch_array($test_types)){ ?>
                                                    <option value="<?php echo $t['type_id']; ?>"
                                                            data-range="<?php echo $t['normal_range']; ?>"
                                                            data-price="<?php echo $t['price']; ?>">
                                                        <?php echo $t['test_name']; ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Reference Range</label>
                                            <input type="text" id="ref_range" class="form-control" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label>Price</label>
                                            <input type="text" id="price" class="form-control" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="test_date">Test Date</label>
                                            <input type="date" name="test_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Client Type</label><br>
                                            <input type="radio" name="client_type" value="patient" checked> HMS Patient
                                            <input type="radio" name="client_type" value="external" style="margin-left:20px;"> External Client
                                        </div>
                                        <div id="patient_fields">
                                            <div class="form-group">
                                                <label for="patient_id">Select Patient</label>
                                                <select name="patient_id" class="form-control" required>
                                                    <option value="">Select Patient</option>
                                                    <?php while($p = mysqli_fetch_array($patients)){ ?>
                                                        <option value="<?php echo $p['ID']; ?>"><?php echo $p['PatientName']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="doctor_id">Referring Doctor</label>
                                                <select name="doctor_id" class="form-control">
                                                    <option value="">Select Doctor</option>
                                                    <?php while($d = mysqli_fetch_array($doctors)){ ?>
                                                        <option value="<?php echo $d['id']; ?>"><?php echo $d['doctorName']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div id="client_fields" style="display:none;">
                                            <div class="form-group">
                                                <label for="client_id">Select External Client</label>
                                                <select name="client_id" class="form-control">
                                                    <option value="">Select Client</option>
                                                    <?php while($c = mysqli_fetch_array($clients)){ ?>
                                                        <option value="<?php echo $c['id']; ?>"><?php echo $c['name']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-success">
                                            <i class="fa fa-plus"></i> Add Test
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Form -->

            </div>
        </div>
    </div>
    <?php include('../include/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        // Show ref range + price when selecting test
        $('#type_id').change(function(){
            let range = $(this).find(':selected').data('range');
            let price = $(this).find(':selected').data('price');
            $('#ref_range').val(range);
            $('#price').val(price);
        });

        // Toggle client fields
        $('input[name="client_type"]').change(function(){
            if($(this).val() == 'patient'){
                $('#patient_fields').show();
                $('#client_fields').hide();
            } else {
                $('#patient_fields').hide();
                $('#client_fields').show();
            }
        });
    });
</script>
</body>
</html>
