<?php
// Result Templates for different test types
$result_templates = [
    'blood_test' => [
        'name' => 'Complete Blood Count (CBC)',
        'parameters' => [
            'Hemoglobin' => ['unit' => 'g/dL', 'normal_range' => '12-16 (F), 14-18 (M)'],
            'Hematocrit' => ['unit' => '%', 'normal_range' => '36-46 (F), 41-53 (M)'],
            'WBC Count' => ['unit' => '×10³/μL', 'normal_range' => '4.0-11.0'],
            'Platelet Count' => ['unit' => '×10³/μL', 'normal_range' => '150-450'],
            'RBC Count' => ['unit' => '×10⁶/μL', 'normal_range' => '4.2-5.4 (F), 4.7-6.1 (M)']
        ]
    ],
    'urine_test' => [
        'name' => 'Urine Analysis',
        'parameters' => [
            'Color' => ['unit' => '', 'normal_range' => 'Pale yellow to amber'],
            'Appearance' => ['unit' => '', 'normal_range' => 'Clear'],
            'pH' => ['unit' => '', 'normal_range' => '4.5-8.0'],
            'Protein' => ['unit' => '', 'normal_range' => 'Negative'],
            'Glucose' => ['unit' => '', 'normal_range' => 'Negative']
        ]
    ],
    'biochemistry' => [
        'name' => 'Biochemical Tests',
        'parameters' => [
            'Blood Glucose' => ['unit' => 'mg/dL', 'normal_range' => '70-100 (Fasting)'],
            'Total Cholesterol' => ['unit' => 'mg/dL', 'normal_range' => '< 200'],
            'Triglycerides' => ['unit' => 'mg/dL', 'normal_range' => '< 150'],
            'HDL Cholesterol' => ['unit' => 'mg/dL', 'normal_range' => '> 40'],
            'LDL Cholesterol' => ['unit' => 'mg/dL', 'normal_range' => '< 100']
        ]
    ],
    'thyroid' => [
        'name' => 'Thyroid Function Test',
        'parameters' => [
            'T3' => ['unit' => 'ng/dL', 'normal_range' => '80-200'],
            'T4' => ['unit' => 'μg/dL', 'normal_range' => '4.5-11.2'],
            'TSH' => ['unit' => 'μIU/mL', 'normal_range' => '0.27-4.2'],
            'Free T3' => ['unit' => 'pg/mL', 'normal_range' => '2.0-4.4'],
            'Free T4' => ['unit' => 'ng/dL', 'normal_range' => '0.93-1.7']
        ]
    ],
    'liver_function' => [
        'name' => 'Liver Function Test',
        'parameters' => [
            'Total Bilirubin' => ['unit' => 'mg/dL', 'normal_range' => '0.3-1.2'],
            'Direct Bilirubin' => ['unit' => 'mg/dL', 'normal_range' => '0.0-0.3'],
            'SGOT (AST)' => ['unit' => 'U/L', 'normal_range' => '5-40'],
            'SGPT (ALT)' => ['unit' => 'U/L', 'normal_range' => '7-56'],
            'Alkaline Phosphatase' => ['unit' => 'U/L', 'normal_range' => '44-147']
        ]
    ]
];
?>